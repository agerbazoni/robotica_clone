import os

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration, PythonExpression
from launch_ros.actions import Node


def generate_launch_description():
    # Config de RViz ubicada junto a este launch file (rviz.rviz en el mismo directorio).
    launch_dir = os.path.dirname(os.path.realpath(__file__))
    rviz_config = os.path.join(launch_dir, 'rviz.rviz')
    # Config aparte para el robot real: identica pero con Fixed Frame namespaced (tb4_0/map),
    # que es el frame en el que vive el mapa del robot real. La de sim usa 'map' a secas.
    rviz_config_real = os.path.join(launch_dir, 'rviz_real.rviz')

    robot_arg = DeclareLaunchArgument(
        'robot',
        default_value='simulado',
        description="Tipo de robot: 'simulado' o 'real'",
    )
    map_path_arg = DeclareLaunchArgument(
        'map_path',
        default_value='/home/alumno1/Documents/ros_ws/mapa.npz',
        description='Ruta al archivo .npz del mapa (usado por nodo_b de parteb)',
    )
    camera_topic_sim_arg = DeclareLaunchArgument(
        'camera_topic_sim',
        default_value='/camera/image_raw',
        description='Tópico de imagen a usar cuando robot:=simulado (ajustar según el mundo de Gazebo)',
    )
    camera_info_topic_sim_arg = DeclareLaunchArgument(
        'camera_info_topic_sim',
        default_value='/camera/camera_info',
        description='Tópico de camera_info a usar cuando robot:=simulado',
    )
    use_nodo_b_arg = DeclareLaunchArgument(
        'use_nodo_b',
        default_value='true',
        description='Si es true, levanta también nodo_b (parteb) para ejecutar localización/planificación/control',
    )
    use_rviz_arg = DeclareLaunchArgument(
        'use_rviz',
        default_value='true',
        description='Si es true, levanta RViz con la config rviz.rviz de este directorio',
    )
    # Namespace del robot real cuyo arbol de TF hay que remapear a /tf y /tf_static
    # (el TB4 publica su TF namespaced, y RViz escucha en /tf global). Cambiar a tb4_1
    # si se visualiza ese robot en vez de tb4_0.
    tf_namespace_arg = DeclareLaunchArgument(
        'tf_namespace',
        default_value='tb4_0',
        description='Namespace del robot cuyo TF se remapea a /tf en RViz (solo robot:=real)',
    )

    robot = LaunchConfiguration('robot')
    map_path = LaunchConfiguration('map_path')
    camera_topic_sim = LaunchConfiguration('camera_topic_sim')
    camera_info_topic_sim = LaunchConfiguration('camera_info_topic_sim')
    use_nodo_b = LaunchConfiguration('use_nodo_b')
    use_rviz = LaunchConfiguration('use_rviz')
    tf_namespace = LaunchConfiguration('tf_namespace')

    # Condiciones: RViz activo, y luego segun sea real o no (para aplicar o no el remap de TF)
    is_real = PythonExpression(["'", robot, "' == 'real'"])
    rviz_real = PythonExpression(
        ["'", use_rviz, "' == 'true' and '", robot, "' == 'real'"])
    rviz_no_real = PythonExpression(
        ["'", use_rviz, "' == 'true' and '", robot, "' != 'real'"])

    # El SLAM estima directamente en el frame de la odometria y NO publica la TF map->odom,
    # asi que el frame del mapa queda desconectado del arbol del robot y RViz no puede ubicarlo.
    # Publicamos map->odom identidad (map y odom coinciden) en el tf_static del namespace del
    # robot, que es el que RViz escucha (remapeado). Solo para robot:=real.
    map_to_odom_static = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='map_to_odom_static',
        output='screen',
        arguments=[
            '--frame-id', [tf_namespace, '/map'],
            '--child-frame-id', [tf_namespace, '/odom'],
        ],
        remappings=[
            ('/tf', ['/', tf_namespace, '/tf']),
            ('/tf_static', ['/', tf_namespace, '/tf_static']),
        ],
        condition=IfCondition(is_real),
    )

    vision_node = Node(
        package='partec',
        executable='vision',
        name='vision_node',
        output='screen',
        parameters=[{
            'robot': robot,
            'camera_topic_sim': camera_topic_sim,
            'camera_info_topic_sim': camera_info_topic_sim,
        }],
    )

    cerebro_node = Node(
        package='partec',
        executable='cerebro',
        name='state_machine_node',
        output='screen',
        parameters=[{'robot': robot, 'map_path': map_path}],
    )

    # nodo_b de parteb resuelve localización + planificación + path following;
    # el cerebro de partec solo decide A DONDE mandarlo (explorar vs. ir al cono).
    nodo_b_node = Node(
        package='parteb',
        executable='nodo_b',
        name='nodo_b',
        output='screen',
        parameters=[{'map_path': map_path, 'robot': robot}],
        condition=IfCondition(use_nodo_b),
    )

    # RViz para robot real: el TB4 publica su TF namespaced (p.ej. /tb4_0/tf), pero
    # RViz escucha en /tf global. Sin este remap RViz no puede transformar los frames
    # y no dibuja mapa/scan/robot.
    rviz_node_real = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        arguments=['-d', rviz_config_real],
        remappings=[
            ('/tf', ['/', tf_namespace, '/tf']),
            ('/tf_static', ['/', tf_namespace, '/tf_static']),
        ],
        condition=IfCondition(rviz_real),
    )

    # RViz para simulado: TF en /tf global, sin remap.
    rviz_node_sim = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        arguments=['-d', rviz_config],
        condition=IfCondition(rviz_no_real),
    )

    return LaunchDescription([
        robot_arg,
        map_path_arg,
        camera_topic_sim_arg,
        camera_info_topic_sim_arg,
        use_nodo_b_arg,
        use_rviz_arg,
        tf_namespace_arg,
        vision_node,
        cerebro_node,
        nodo_b_node,
        map_to_odom_static,
        rviz_node_real,
        rviz_node_sim,
    ])